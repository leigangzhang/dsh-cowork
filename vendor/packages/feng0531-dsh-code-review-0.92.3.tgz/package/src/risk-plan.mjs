import {changeMap} from './change-map.mjs';
// Decisions use complete approved file churn, not one window's visible subset.
export function riskPlanningDecision(files) {
 if(!Array.isArray(files)||!files.length||files.length>4)throw new Error('Invalid planning selection');
 const counts=files.map(f=>{
  if(typeof f?.left?.text!=='string'||typeof f?.right?.text!=='string')throw new Error('Missing planning source');
  const c=changeMap(f.left.text,f.right.text);
  return c.status==='unchanged'?0:c.precision==='exact'?c.edits.reduce((n,e)=>n+e.old.count+e.new.count,0):null;
 });
 if(counts.includes(null))return {required:true,reason:'unknown-churn',totalChanged:null,maxFileChanged:null};
 const totalChanged=counts.reduce((a,b)=>a+b,0),maxFileChanged=Math.max(...counts);
 return {required:maxFileChanged>=50||(files.length>=2&&totalChanged>=100),reason:maxFileChanged>=50?'file-threshold':files.length>=2&&totalChanged>=100?'group-threshold':'below-threshold',totalChanged,maxFileChanged};
}
// Plans are untrusted hypotheses, never findings or authority to expand scope.
export { RISK_PLAN_INSTRUCTIONS } from './prompts.mjs';
export function validateRiskPlan(response, files, catalog) {
 const value = typeof response === 'string' ? JSON.parse(response) : response;
 if (!value || Object.keys(value).some(k => k !== 'risks') || !Array.isArray(value.risks) || value.risks.length > 20 || Buffer.byteLength(JSON.stringify(value)) > 64*1024) throw new Error('Invalid risk plan');
 const ids = new Set(), sources = new Set(catalog.map(s => s.id));
 const byId = new Map(files.map(f => [f.fileId,f]));
 const text = t => typeof t === 'string' && t.trim().length > 0 && t.length <= 2000;
 const unique = a => Array.isArray(a) && a.every(x => typeof x === 'string') && new Set(a).size === a.length;
 return value.risks.map(r => {
  if (!r || Object.keys(r).some(k => !['id','fileIds','editRefs','question','trigger','impact','checks','sourceIds'].includes(k)) || !text(r.id) || ids.has(r.id) || !unique(r.fileIds) || r.fileIds.length < 1 || r.fileIds.length > 4 || r.fileIds.some(id => !byId.has(id)) || !['question','trigger','impact'].every(k => text(r[k])) || !unique(r.checks) || r.checks.length < 1 || r.checks.length > 8 || !r.checks.every(text) || !unique(r.sourceIds) || r.sourceIds.length > 8 || r.sourceIds.some(id => !sources.has(id)) || !Array.isArray(r.editRefs) || !r.editRefs.length || r.editRefs.length > 20) throw new Error('Invalid risk hypothesis');
  const refs = new Set();
  for (const ref of r.editRefs) {
   if (!ref || Object.keys(ref).length !== 2 || !r.fileIds.includes(ref.fileId) || !byId.get(ref.fileId)?.edits.some(e => e.id === ref.editId)) throw new Error('Unknown risk edit');
   const key=JSON.stringify([ref.fileId,ref.editId]);if(refs.has(key))throw new Error('Duplicate risk edit');refs.add(key);
  }
  ids.add(r.id);return {...structuredClone(r),status:'hypothesis',causality:'unverified'};
 });
}
